import sys
import numpy as np
import pandas as pd
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                           QHBoxLayout, QTabWidget, QPushButton, QLabel,QTableWidget, QTableWidgetItem,
                           QComboBox, QFileDialog, QSpinBox, QDoubleSpinBox,
                           QGroupBox, QScrollArea, QTextEdit, QStatusBar,
                           QProgressBar, QCheckBox, QGridLayout, QMessageBox,
                           QDialog, QLineEdit)
from PyQt6.QtCore import Qt
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from sklearn import datasets, preprocessing, model_selection
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score, mean_squared_error, confusion_matrix, mean_absolute_error, roc_curve, auc
from sklearn.linear_model import HuberRegressor
import tensorflow as tf
from tensorflow.keras import layers, models, optimizers
from sklearn.svm import SVR #Library for SVR
class MLCourseGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Machine Learning Course GUI")
        self.setGeometry(100, 100, 1400, 800)
        
        # Initialize main widget and layout
        self.main_widget = QWidget()
        self.setCentralWidget(self.main_widget)
        self.layout = QVBoxLayout(self.main_widget)
        
        # Initialize data containers
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        self.current_model = None
        
        # Neural network configuration
        self.layer_config = []
        
        # Create components
        self.create_data_section()
        self.create_tabs()
        self.create_visualization()
        self.create_status_bar()

        # Adding Combo box for filling the missing data
        self.missing_data_combo = QComboBox()
        self.missing_data_combo.addItems(["Mean","Interpolation","Forward Fill","Backward Fill"])

        # The Button That Fills The Missing Data
        self.fill_missing_data_btn = QPushButton("Fill Missng Data")
        self.fill_missing_data_btn.clicked.connect(self.handle_missing_data)

    def handle_missing_data(self):
        if self.dataset is None:
            self.show_error("Please load a dataset first!")
            return

        method = self.missing_data_combo.currentText()

        if method == "Mean":
            self.dataset.fillna(self.dataset.mean(), inplace=True)
        elif method == "Interpolation":
            self.dataset.interpolate(inplace=True)
        elif method == "Forward Fill":
            self.dataset.fillna(method='ffill', inplace=True)
        elif method == "Backward Fill":
            self.dataset.fillna(method='bfill', inplace=True)
        else:
            self.show_error("Invalid method selected!")
            return

        self.status_bar.showMessage(f"Missing data handled using {method}")
        
    def load_dataset(self):
        """Load selected dataset"""
        try:
            dataset_name = self.dataset_combo.currentText()
            
            if dataset_name == "Load Custom Dataset":
                return
            
            # Load selected dataset
            if dataset_name == "Iris Dataset":
                data = datasets.load_iris()
            elif dataset_name == "Breast Cancer Dataset":
                data = datasets.load_breast_cancer()
            elif dataset_name == "Digits Dataset":
                data = datasets.load_digits()
            elif dataset_name == "Boston Housing Dataset":
                data = datasets.load_boston()
            elif dataset_name == "MNIST Dataset":
                (X_train, y_train), (X_test, y_test) = tf.keras.datasets.mnist.load_data()
                self.X_train, self.X_test = X_train, X_test
                self.y_train, self.y_test = y_train, y_test
                self.status_bar.showMessage(f"Loaded {dataset_name}")
                return
            
            # Split data
            test_size = self.split_spin.value()
            self.X_train, self.X_test, self.y_train, self.y_test = \
                model_selection.train_test_split(data.data, data.target, 
                                              test_size=test_size, 
                                              random_state=42)
            
            # Apply scaling if selected
            self.apply_scaling()
            
            self.status_bar.showMessage(f"Loaded {dataset_name}")
            
        except Exception as e:
            self.show_error(f"Error loading dataset: {str(e)}")
    
    def load_custom_data(self):
        """Load custom dataset from CSV file"""
        try:
            file_name, _ = QFileDialog.getOpenFileName(
                self,
                "Load Dataset",
                "",
                "CSV files (*.csv)"
            )
            
            if file_name:
                # Load data
                data = pd.read_csv(file_name)
                
                # Ask user to select target column
                target_col = self.select_target_column(data.columns)
                
                if target_col:
                    X = data.drop(target_col, axis=1)
                    y = data[target_col]
                    
                    # Split data
                    test_size = self.split_spin.value()
                    self.X_train, self.X_test, self.y_train, self.y_test = \
                        model_selection.train_test_split(X, y, 
                                                      test_size=test_size, 
                                                      random_state=42)
                    
                    # Apply scaling if selected
                    self.apply_scaling()
                    
                    self.status_bar.showMessage(f"Loaded custom dataset: {file_name}")
                    
        except Exception as e:
            self.show_error(f"Error loading custom dataset: {str(e)}")
    
    def select_target_column(self, columns):
        """Dialog to select target column from dataset"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Select Target Column")
        layout = QVBoxLayout(dialog)
        
        combo = QComboBox()
        combo.addItems(columns)
        layout.addWidget(combo)
        
        btn = QPushButton("Select")
        btn.clicked.connect(dialog.accept)
        layout.addWidget(btn)
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            return combo.currentText()
        return None
    
    def apply_scaling(self):
        """Apply selected scaling method to the data"""
        scaling_method = self.scaling_combo.currentText()
        
        if scaling_method != "No Scaling":
            try:
                if scaling_method == "Standard Scaling":
                    scaler = preprocessing.StandardScaler()
                elif scaling_method == "Min-Max Scaling":
                    scaler = preprocessing.MinMaxScaler()
                elif scaling_method == "Robust Scaling":
                    scaler = preprocessing.RobustScaler()
                
                self.X_train = scaler.fit_transform(self.X_train)
                self.X_test = scaler.transform(self.X_test)
                
            except Exception as e:
                self.show_error(f"Error applying scaling: {str(e)}")
    def create_data_section(self):
        """Create the data loading and preprocessing section"""
        data_group = QGroupBox("Data Management")
        data_layout = QHBoxLayout()
        
        # Dataset selection
        self.dataset_combo = QComboBox()
        self.dataset_combo.addItems([
            "Load Custom Dataset",
            "Iris Dataset",
            "Breast Cancer Dataset",
            "Digits Dataset",
            "Boston Housing Dataset",
            "MNIST Dataset"
        ])
        self.dataset_combo.currentIndexChanged.connect(self.load_dataset)
        
        # Data loading button
        self.load_btn = QPushButton("Load Data")
        self.load_btn.clicked.connect(self.load_custom_data)
        
        # Preprocessing options
        self.scaling_combo = QComboBox()
        self.scaling_combo.addItems([
            "No Scaling",
            "Standard Scaling",
            "Min-Max Scaling",
            "Robust Scaling"
        ])
        
        # Train-test split options
        self.split_spin = QDoubleSpinBox()
        self.split_spin.setRange(0.1, 0.9)
        self.split_spin.setValue(0.2)
        self.split_spin.setSingleStep(0.1)
        
        # Add widgets to layout
        data_layout.addWidget(QLabel("Dataset:"))
        data_layout.addWidget(self.dataset_combo)
        data_layout.addWidget(self.load_btn)
        data_layout.addWidget(QLabel("Scaling:"))
        data_layout.addWidget(self.scaling_combo)
        data_layout.addWidget(QLabel("Test Split:"))
        data_layout.addWidget(self.split_spin)
        
        data_group.setLayout(data_layout)
        self.layout.addWidget(data_group)


        # For Train/Validation/Test Split 
        self.train_split_spin = QDoubleSpinBox()
        self.train_split_spin.setRange(0.5, 0.9)
        self.train_split_spin.setValue(0.7)
        self.train_split_spin.setSingleStep(0.05)

        self.val_split_spin = QDoubleSpinBox()
        self.val_split_spin.setRange(0.05, 0.3)
        self.val_split_spin.setValue(0.15)
        self.val_split_spin.setSingleStep(0.05)

        # Add to Layout
        data_layout.addWidget(QLabel("Train Split:"))
        data_layout.addWidget(self.train_split_spin)
        data_layout.addWidget(QLabel("Validation Split:"))
        data_layout.addWidget(self.val_split_spin)

    def custom_train_val_test_split(self, X, y):
        """Split data into Train, Validation, and Test sets based on user input"""
        train_size = self.train_split_spin.value()
        val_size = self.val_split_spin.value()
        test_size = 1.0 - train_size - val_size

        if test_size <= 0:
            self.show_error("Invalid split! Please adjust train/validation ratios.")
            return None, None, None, None, None, None

        # İlk Train/Test Split
        X_temp, X_test, y_temp, y_test = model_selection.train_test_split(X, y, test_size=test_size, random_state=42)

        # Şimdi Train/Validation Split
        val_ratio_adjusted = val_size / (train_size + val_size)
        X_train, X_val, y_train, y_val = model_selection.train_test_split(X_temp, y_temp, test_size=val_ratio_adjusted, random_state=42)

        return X_train, X_val, X_test, y_train, y_val, y_test




    def create_tabs(self):
        """Create tabs for different ML topics"""
        self.tab_widget = QTabWidget()
        
        # Create individual tabs
        tabs = [
            ("Classical ML", self.create_classical_ml_tab),
            ("Deep Learning", self.create_deep_learning_tab),
            ("Dimensionality Reduction", self.create_dim_reduction_tab),
            ("Reinforcement Learning", self.create_rl_tab)
        ]
        
        for tab_name, create_func in tabs:
            scroll = QScrollArea()
            tab_widget = create_func()
            scroll.setWidget(tab_widget)
            scroll.setWidgetResizable(True)
            self.tab_widget.addTab(scroll, tab_name)
        
        self.layout.addWidget(self.tab_widget)
    
    def create_classical_ml_tab(self):
        """Create the classical machine learning algorithms tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        self.regression_loss_combo = QComboBox()
        regression_layout = QVBoxLayout()
        #Support Vector Regression (SVR)
        svr_group = QGroupBox("Support Vector Regression (SVR)")
        svr_layout = QVBoxLayout()

        # Kernel selection dropdown
        self.svr_kernel_combo = QComboBox()
        self.svr_kernel_combo.addItems(["linear", "rbf", "poly"])
        self.svr_kernel_combo.setCurrentIndex(0)

        # C parameter
        self.svr_c_spin = QDoubleSpinBox()
        self.svr_c_spin.setRange(0.01, 100.0)
        self.svr_c_spin.setValue(1.0)

        # Epsilon parameter
        self.svr_epsilon_spin = QDoubleSpinBox()
        self.svr_epsilon_spin.setRange(0.01, 1.0)
        self.svr_epsilon_spin.setValue(0.1)

        # Add widgets to SVR layout
        svr_layout.addWidget(QLabel("Kernel:"))
        svr_layout.addWidget(self.svr_kernel_combo)
        svr_layout.addWidget(QLabel("C Parameter:"))
        svr_layout.addWidget(self.svr_c_spin)
        svr_layout.addWidget(QLabel("Epsilon:"))
        svr_layout.addWidget(self.svr_epsilon_spin)

        # Train button for SVR
        svr_train_btn = QPushButton("Train SVR")
        svr_train_btn.clicked.connect(lambda: self.train_model("SVR", {}))
        svr_layout.addWidget(svr_train_btn)
        svr_group.setLayout(svr_layout)

        regression_layout.addWidget(svr_group)
        # Regression section
        regression_group = QGroupBox("Regression")
        regression_layout = QVBoxLayout()
        
        # Linear Regression
        lr_group = self.create_algorithm_group(
            "Linear Regression",
            {"fit_intercept": "checkbox",
             "normalize": "checkbox"}
        )
        regression_layout.addWidget(lr_group)
        # Huber Regressor
        huber_group = self.create_algorithm_group(
            "Huber Regressor",
            {"epsilon": "double"}
        )
        regression_layout.addWidget(huber_group)
     
        # Logistic Regression
        logistic_group = self.create_algorithm_group(
            "Logistic Regression",
            {"C": "double",
             "max_iter": "int",
             "multi_class": ["ovr", "multinomial"]}
        )
        regression_layout.addWidget(logistic_group)
        # Loss Function Selection
        loss_func_group = self.create_algorithm_group(
            "Loss Function:",
            {"MSE": "checkbox",
             "MAE": "checkbox",
             "Huber Loss": "checkbox"}
        )
        regression_layout.addWidget(loss_func_group)
        
        regression_group.setLayout(regression_layout)
        layout.addWidget(regression_group, 0, 0)
        
        # Classification section
        classification_group = QGroupBox("Classification")
        classification_layout = QVBoxLayout()
        
        # Naive Bayes
        nb_group = self.create_algorithm_group(
            "Naive Bayes",
            {"var_smoothing": "double"}
        )
        classification_layout.addWidget(nb_group)
        
        # SVM
        svm_group = self.create_algorithm_group(
            "Support Vector Machine",
            {"C": "double",
             "kernel": ["linear", "rbf", "poly"],
             "degree": "int"}
        )
        classification_layout.addWidget(svm_group)
        
        # Decision Trees
        dt_group = self.create_algorithm_group(
            "Decision Tree",
            {"max_depth": "int",
             "min_samples_split": "int",
             "criterion": ["gini", "entropy"]}
        )
        classification_layout.addWidget(dt_group)
        
        # Random Forest
        rf_group = self.create_algorithm_group(
            "Random Forest",
            {"n_estimators": "int",
             "max_depth": "int",
             "min_samples_split": "int"}
        )
        classification_layout.addWidget(rf_group)
        
        # KNN
        knn_group = self.create_algorithm_group(
            "K-Nearest Neighbors",
            {"n_neighbors": "int",
             "weights": ["uniform", "distance"],
             "metric": ["euclidean", "manhattan"]}
        )
        classification_layout.addWidget(knn_group)
        
        classification_group.setLayout(classification_layout)
        layout.addWidget(classification_group, 0, 1)

        # Adding a Model Comparison Table:
        self.comparison_table = QTableWidget()
        self.comparison_table.setColumnCount(5)
        self.comparison_table.setHorizontalHeaderLabels(["Model", "Accuracy", "Precision", "Recall", "F1-Score"])
        layout.addWidget(self.comparison_table, 2, 0, 1, 2)

        # Add the k-Fold Setting to GUI
        self.kfold_spin = QSpinBox()
        self.kfold_spin.setRange(2, 20)
        self.kfold_spin.setValue(5)

        kfold_btn = QPushButton("Perform k-Fold Cross-Validation")
        kfold_btn.clicked.connect(self.perform_kfold_cv)

        layout.addWidget(QLabel("k-Fold Cross Validation (k):"), 3, 0)
        layout.addWidget(self.kfold_spin, 3, 1)
        layout.addWidget(kfold_btn, 3, 2)

        return widget
    
    def perform_kfold_cv(self):
        """Perform k-Fold Cross Validation and show mean/std metrics"""
        try:
            if self.X_train is None or self.y_train is None:
                self.show_error("Please load a dataset first!")
                return

            from sklearn.model_selection import KFold
            from sklearn.metrics import accuracy_score, mean_squared_error

            # If DataFrame, convert numpy to array
            self.X_train = self.X_train.to_numpy() if hasattr(self.X_train, "to_numpy") else self.X_train
            self.y_train = self.y_train.to_numpy() if hasattr(self.y_train, "to_numpy") else self.y_train


            k = self.kfold_spin.value()

            kf = KFold(n_splits=k, shuffle=True, random_state=42)
            mse_scores = []
            rmse_scores = []

            model = self.current_model  # Whatever model the user last trained

            if model is None:
                self.show_error("No trained model found!")
                return

            for train_index, val_index in kf.split(self.X_train):
                X_tr, X_val = self.X_train[train_index], self.X_train[val_index]
                y_tr, y_val = self.y_train[train_index], self.y_train[val_index]

                model.fit(X_tr, y_tr)
                y_pred = model.predict(X_val)
                mse = mean_squared_error(y_val, y_pred)
                rmse = mean_squared_error(y_val, y_pred, squared=False)
                mse_scores.append(mse)
                rmse_scores.append(rmse)
            # Let's Show The Results
            mean_mse = np.mean(mse_scores)
            std_mse = np.std(mse_scores)
            mean_rmse = np.mean(rmse_scores)
            std_rmse = np.std(rmse_scores)
            self.status_bar.showMessage(f"MSE: {mean_mse:.4f} ± {std_mse:.4f} | RMSE: {mean_rmse:.4f} ± {std_rmse:.4f}")
        except Exception as e:
            self.show_error(f"Error performing k-Fold CV: {str(e)}")



    def create_dim_reduction_tab(self):
        """Create the dimensionality reduction tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        # K-Means Group
        kmeans_group = QGroupBox("K-Means Clustering")
        kmeans_layout = QVBoxLayout()
        
        kmeans_params = self.create_algorithm_group(
            "K-Means Parameters",
            {"n_clusters": "int",
             "max_iter": "int",
             "n_init": "int"}
        )
        # K SpinBox (k value selection)
        self.kmeans_k_spin = QSpinBox()
        self.kmeans_k_spin.setRange(1, 20)
        self.kmeans_k_spin.setValue(3)
        # Apply k-Means Button
        apply_kmeans_btn = QPushButton("Apply k-Means")
        apply_kmeans_btn.clicked.connect(self.apply_kmeans)
        # Plot Elbow Method Button
        elbow_btn = QPushButton("Plot Elbow Method")
        elbow_btn.clicked.connect(self.plot_elbow_method)
        # Add to Layout
        kmeans_layout.addWidget(QLabel("Number of Clusters (k):"))
        kmeans_layout.addWidget(self.kmeans_k_spin)
        kmeans_layout.addWidget(apply_kmeans_btn)
        kmeans_layout.addWidget(elbow_btn)

        kmeans_layout.addWidget(kmeans_params)
        kmeans_group.setLayout(kmeans_layout)
        #Add to Grid
        layout.addWidget(kmeans_group, 2, 0)
        
        # PCA section
        pca_group = QGroupBox("Principal Component Analysis")
        pca_layout = QVBoxLayout()
        
        pca_params = self.create_algorithm_group(
            "PCA Parameters",
            {"n_components": "int",
             "whiten": "checkbox"}
        )
        # Number of Components selection
        self.pca_n_components_spin = QSpinBox()
        self.pca_n_components_spin.setRange(1, 100)
        self.pca_n_components_spin.setValue(2)
        # Apply PCA Button
        apply_pca_btn = QPushButton("Apply PCA")
        apply_pca_btn.clicked.connect(self.apply_pca)
        # Add to PCA Layout
        pca_layout.addWidget(QLabel("Number of Components:"))
        pca_layout.addWidget(self.pca_n_components_spin)
        pca_layout.addWidget(apply_pca_btn)


        pca_layout.addWidget(pca_params)
        pca_group.setLayout(pca_layout)

        #Add The Grid to Layout
        layout.addWidget(pca_group, 1, 0)

        # LDA Group
        lda_group = QGroupBox("Linear Discriminant Analysis (LDA)")
        lda_layout = QVBoxLayout()

        # Apply LDA Button
        apply_lda_btn = QPushButton("Apply LDA")
        apply_lda_btn.clicked.connect(self.apply_lda)
        # Add to LDA Layout
        lda_layout.addWidget(apply_lda_btn)
        lda_group.setLayout(lda_layout)
        # Add to Grid Layout
        layout.addWidget(lda_group, 1, 1)
        

        # t-SNE + UMAP Group
        manifold_group = QGroupBox("t-SNE and UMAP")
        manifold_layout = QVBoxLayout()

        # Perplexity setting (for t-SNE )
        self.tsne_perplexity_spin = QSpinBox()
        self.tsne_perplexity_spin.setRange(5, 100)
        self.tsne_perplexity_spin.setValue(30)

        # Dimension selection (2D or 3D)
        self.dimension_combo = QComboBox()
        self.dimension_combo.addItems(["2D", "3D"])

        # Apply t-SNE Button
        apply_tsne_btn = QPushButton("Apply t-SNE")
        apply_tsne_btn.clicked.connect(self.apply_tsne)

        # Apply UMAP Button
        apply_umap_btn = QPushButton("Apply UMAP")
        apply_umap_btn.clicked.connect(self.apply_umap)

        # Add to Layout
        manifold_layout.addWidget(QLabel("Perplexity (t-SNE):"))
        manifold_layout.addWidget(self.tsne_perplexity_spin)
        manifold_layout.addWidget(QLabel("Dimension:"))
        manifold_layout.addWidget(self.dimension_combo)
        manifold_layout.addWidget(apply_tsne_btn)
        manifold_layout.addWidget(apply_umap_btn)

        manifold_group.setLayout(manifold_layout)

        layout.addWidget(manifold_group, 2, 1)

        return widget
    def apply_kmeans(self):
        """Apply k-Means clustering and visualize clusters with Silhouette Score and Plotly"""
        try:
            if self.X_train is None:
                self.show_error("Please load a dataset first!")
                return

            k = self.kmeans_k_spin.value()

            # Create k-Means Model
            kmeans = KMeans(n_clusters=k, random_state=42)
            y_kmeans = kmeans.fit_predict(self.X_train)

            # PCA for visualization
            pca = PCA(n_components=2)
            X_reduced = pca.fit_transform(self.X_train)

            # Draw the Graph in GUI
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            scatter = ax.scatter(X_reduced[:, 0], X_reduced[:, 1], c=y_kmeans, cmap='tab10', edgecolor='k', s=50)
            self.figure.colorbar(scatter)
            ax.set_title(f"k-Means Clustering (k={k})")
            self.canvas.draw()

            # Show Silhouette Score
            self.compute_silhouette_score(self.X_train, y_kmeans)

            # Show Interactive Plotly Visualization
            self.plot_clusters_plotly(X_reduced, y_kmeans, dim=2)

            self.status_bar.showMessage(f"k-Means clustering applied with k={k}.")

        except Exception as e:
            self.show_error(f"Error applying k-Means: {str(e)}")
    
    def compute_silhouette_score(self, X, labels):
        """Compute and display the silhouette score"""
        try:
            from sklearn.metrics import silhouette_score
            score = silhouette_score(X, labels)
            QMessageBox.information(self, "Silhouette Score", f"Silhouette Score: {score:.4f}")
            self.status_bar.showMessage(f"Silhouette Score: {score:.4f}")
        except Exception as e:
            self.show_error(f"Error computing silhouette score: {str(e)}")

    def plot_clusters_plotly(self, X, labels, dim=2):
        """Plot clustering result using Plotly"""
        try:
            import plotly.express as px
            import plotly.io as pio
            pio.renderers.default = 'browser'  # Opens in browser window

            if dim == 2:
                fig = px.scatter(x=X[:, 0], y=X[:, 1], color=labels.astype(str),
                                title="Cluster Visualization (2D)", labels={"color": "Cluster"})
            else:
                fig = px.scatter_3d(x=X[:, 0], y=X[:, 1], z=X[:, 2], color=labels.astype(str),
                                    title="Cluster Visualization (3D)", labels={"color": "Cluster"})

            fig.show()
        except Exception as e:
            self.show_error(f"Error plotting with Plotly: {str(e)}")


    def plot_elbow_method(self):
        """Plot Elbow Method to find optimal k"""
        try:
            if self.X_train is None:
                self.show_error("Please load a dataset first!")
                return

            wcss = []  # Within-cluster sum of squares
            K_range = range(1, 11)

            for k in K_range:
                kmeans = KMeans(n_clusters=k, random_state=42)
                kmeans.fit(self.X_train)
                wcss.append(kmeans.inertia_)

            # Draw the Graph
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            ax.plot(K_range, wcss, marker='o')
            ax.set_xlabel('Number of clusters (k)')
            ax.set_ylabel('WCSS')
            ax.set_title('Elbow Method For Optimal k')
            ax.grid(True)
            self.canvas.draw()

            self.status_bar.showMessage("Elbow method plotted.")

        except Exception as e:
            self.show_error(f"Error plotting Elbow Method: {str(e)}")


    def apply_pca(self):
        """Apply PCA to the dataset and plot explained variance"""
        try:
            if self.X_train is None:
                self.show_error("Please load a dataset first!")
                return

            n_components = self.pca_n_components_spin.value()
        
            # Create the PCA Model
            pca = PCA(n_components=n_components)
            pca.fit(self.X_train)
        
            explained_variance = pca.explained_variance_ratio_

            # Draw the Graph
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            ax.plot(np.cumsum(explained_variance), marker='o')
            ax.set_xlabel("Number of Components")
            ax.set_ylabel("Cumulative Explained Variance")
            ax.set_title("PCA Explained Variance")
            ax.grid(True)

            self.canvas.draw()

            self.status_bar.showMessage(f"PCA applied with {n_components} components.")

        except Exception as e:
            self.show_error(f"Error applying PCA: {str(e)}")

    def apply_lda(self):
        """Apply LDA to the dataset and plot 2D projection"""
        try:
            if self.X_train is None or self.y_train is None:
                self.show_error("Please load a dataset first!")
                return
            if len(np.unique(self.y_train)) > 20:
                self.show_error("Current dataset is not suitable for LDA(needs classification labels). Please load a classification dataset(like Irish,Digits,etc.).")
                return
            # Create The LDA model
            from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA

            lda = LDA(n_components=2)
            X_r = lda.fit_transform(self.X_train, self.y_train)

            # Draw The Graph
            self.figure.clear()
            ax = self.figure.add_subplot(111)

            scatter = ax.scatter(X_r[:, 0], X_r[:, 1], c=self.y_train, cmap='viridis', edgecolor='k', s=50)
            self.figure.colorbar(scatter)
            ax.set_title("LDA 2D Projection")

            self.canvas.draw()

            self.status_bar.showMessage("LDA applied and visualized.")

        except Exception as e:
            self.show_error(f"Error applying LDA: {str(e)}")
    def apply_tsne(self):
        """Apply t-SNE for dimensionality reduction"""
        try:
            from sklearn.manifold import TSNE

            if self.X_train is None:
                self.show_error("Please load a dataset first!")
                return

            perplexity = self.tsne_perplexity_spin.value()
            n_components = 2 if self.dimension_combo.currentText() == "2D" else 3

            tsne = TSNE(n_components=n_components, perplexity=perplexity, random_state=42)
            X_embedded = tsne.fit_transform(self.X_train)

            # Draw The Graph
            self.figure.clear()
            if n_components == 2:
                ax = self.figure.add_subplot(111)
                scatter = ax.scatter(X_embedded[:, 0], X_embedded[:, 1], c=self.y_train, cmap="viridis", edgecolor='k', s=50)
                self.figure.colorbar(scatter)
                ax.set_title("t-SNE 2D Projection")
            else:
                ax = self.figure.add_subplot(111, projection='3d')
                scatter = ax.scatter(X_embedded[:, 0], X_embedded[:, 1], X_embedded[:, 2], c=self.y_train, cmap="viridis", edgecolor='k', s=50)
                ax.set_title("t-SNE 3D Projection")

            self.canvas.draw()

            self.status_bar.showMessage("t-SNE applied.")

        except Exception as e:
            self.show_error(f"Error applying t-SNE: {str(e)}")

    def apply_umap(self):
        """Apply UMAP for dimensionality reduction"""
        try:
            import umap

            if self.X_train is None:
                self.show_error("Please load a dataset first!")
                return

            n_components = 2 if self.dimension_combo.currentText() == "2D" else 3

            umap_model = umap.UMAP(n_components=n_components, random_state=42)
            X_umap = umap_model.fit_transform(self.X_train)

            # Draw The Graph
            self.figure.clear()
            if n_components == 2:
                ax = self.figure.add_subplot(111)
                scatter = ax.scatter(X_umap[:, 0], X_umap[:, 1], c=self.y_train, cmap="plasma", edgecolor='k', s=50)
                self.figure.colorbar(scatter)
                ax.set_title("UMAP 2D Projection")
            else:
                ax = self.figure.add_subplot(111, projection='3d')
                scatter = ax.scatter(X_umap[:, 0], X_umap[:, 1], X_umap[:, 2], c=self.y_train, cmap="plasma", edgecolor='k', s=50)
                ax.set_title("UMAP 3D Projection")

            self.canvas.draw()

            self.status_bar.showMessage("UMAP applied.")

        except Exception as e:
            self.show_error(f"Error applying UMAP: {str(e)}")

    def create_rl_tab(self):
        """Create the reinforcement learning tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        # Environment selection
        env_group = QGroupBox("Environment")
        env_layout = QVBoxLayout()
        
        self.env_combo = QComboBox()
        self.env_combo.addItems([
            "CartPole-v1",
            "MountainCar-v0",
            "Acrobot-v1"
        ])
        env_layout.addWidget(self.env_combo)
        
        env_group.setLayout(env_layout)
        layout.addWidget(env_group, 0, 0)
        
        # RL Algorithm selection
        algo_group = QGroupBox("RL Algorithm")
        algo_layout = QVBoxLayout()
        
        self.rl_algo_combo = QComboBox()
        self.rl_algo_combo.addItems([
            "Q-Learning",
            "SARSA",
            "DQN"
        ])
        algo_layout.addWidget(self.rl_algo_combo)
        
        algo_group.setLayout(algo_layout)
        layout.addWidget(algo_group, 0, 1)
        
        return widget
    
    def create_visualization(self):
        """Create the visualization section"""
        viz_group = QGroupBox("Visualization")
        viz_layout = QHBoxLayout()
        
        # Create matplotlib figure
        self.figure = Figure(figsize=(8, 6))
        self.canvas = FigureCanvas(self.figure)
        viz_layout.addWidget(self.canvas)
        
        # Metrics display
        self.metrics_text = QTextEdit()
        self.metrics_text.setReadOnly(True)
        viz_layout.addWidget(self.metrics_text)
        
        viz_group.setLayout(viz_layout)
        self.layout.addWidget(viz_group)
    
    def create_status_bar(self):
        """Create the status bar"""
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        
        # Add progress bar
        self.progress_bar = QProgressBar()
        self.status_bar.addPermanentWidget(self.progress_bar)
    
    def create_algorithm_group(self, name, params):
        """Helper method to create algorithm parameter groups"""
        group = QGroupBox(name)
        layout = QVBoxLayout()
        
        # Create parameter inputs
        param_widgets = {}
        for param_name, param_type in params.items():
            param_layout = QHBoxLayout()
            param_layout.addWidget(QLabel(f"{param_name}:"))
            
            if param_type == "int":
                widget = QSpinBox()
                widget.setRange(1, 1000)
            elif param_type == "double":
                widget = QDoubleSpinBox()
                widget.setRange(0.0001, 1000.0)
                widget.setSingleStep(0.1)
            elif param_type == "checkbox":
                widget = QCheckBox()
            elif isinstance(param_type, list):
                widget = QComboBox()
                widget.addItems(param_type)
            
            param_layout.addWidget(widget)
            param_widgets[param_name] = widget
            layout.addLayout(param_layout)
        
        # Add train button
        train_btn = QPushButton(f"Train {name}")
        train_btn.clicked.connect(lambda: self.train_model(name, param_widgets))
        layout.addWidget(train_btn)
        
        group.setLayout(layout)
        return group
    from sklearn.metrics import mean_squared_error, mean_absolute_error
    from sklearn.linear_model import LinearRegression, HuberRegressor

    def train_model(self, model_name, params):
        """Train regression/classification model with selected loss function"""
        try:
            print(f"DEBUG: Model training started for {model_name}")  # 🔍 For Debuging 

            if self.X_train is None or self.y_train is None:
                self.show_error("Please load a dataset first!")
                return

            # If DataFrame, convert it numpy array
            self.X_train = self.X_train.to_numpy() if hasattr(self.X_train, "to_numpy") else self.X_train
            self.y_train = self.y_train.to_numpy() if hasattr(self.y_train, "to_numpy") else self.y_train
            self.X_test = self.X_test.to_numpy() if hasattr(self.X_test, "to_numpy") else self.X_test
            self.y_test = self.y_test.to_numpy() if hasattr(self.y_test, "to_numpy") else self.y_test

            # Model and Type Selection
            regression_models = ["Linear Regression", "Huber Regressor", "Support Vector Machine", "K-Nearest Neighbors", "Random Forest", "Decision Tree"]
            classification_models = ["Logistic Regression", "Naive Bayes"]

            if model_name in regression_models:
                problem_type = "regression"
            elif model_name in classification_models:
                problem_type = "classification"
            else:
                self.show_error(f"Unsupported model: {model_name}")
                return

            # Model Creation
            if model_name == "Linear Regression":
                from sklearn.linear_model import LinearRegression
                model = LinearRegression(**params)

            elif model_name == "Huber Regressor":
                from sklearn.linear_model import HuberRegressor
                model = HuberRegressor(**params)

            elif model_name == "Support Vector Machine":
                from sklearn.svm import SVR
                kernel = self.svr_kernel_combo.currentText()
                C = self.svr_c_spin.value()
                epsilon = self.svr_epsilon_spin.value()
                model = SVR(kernel=kernel, C=C, epsilon=epsilon)

            elif model_name == "K-Nearest Neighbors":
                from sklearn.neighbors import KNeighborsRegressor
                model = KNeighborsRegressor(**params)

            elif model_name == "Random Forest":
                from sklearn.ensemble import RandomForestRegressor
                model = RandomForestRegressor(**params)

            elif model_name == "Logistic Regression":
                from sklearn.linear_model import LogisticRegression
                model = LogisticRegression(**params)

            elif model_name == "Decision Tree":
                from sklearn.tree import DecisionTreeRegressor
                model = DecisionTreeRegressor(**params)

            elif model_name == "Naive Bayes":
                from sklearn.naive_bayes import GaussianNB
                model = GaussianNB(**params)

            else:
                self.show_error(f"Unsupported model: {model_name}")
                return

            # train The Model
            model.fit(self.X_train, self.y_train)
            self.current_model = model

            # Makeing a prediction
            y_pred = model.predict(self.X_test)

            # Calculate the Loss
            if problem_type == "regression":
                from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
                loss_function = self.regression_loss_combo.currentText()
                if loss_function == "MSE":
                    loss = mean_squared_error(self.y_test, y_pred)
                elif loss_function == "MAE":
                    loss = mean_absolute_error(self.y_test, y_pred)
                elif loss_function == "Huber Loss":
                    loss = mean_squared_error(self.y_test, y_pred, squared=False)
                else:
                    loss = None
                r2 = r2_score(self.y_test, y_pred)
                result_msg = (
                    f"{model_name} trained with {loss_function}\n"
                    f"Loss: {loss:.4f}\n"
                    f"R² Score: {r2:.4f}"
                )
            else:  # classification
                from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
                acc = accuracy_score(self.y_test, y_pred)
                prec = precision_score(self.y_test, y_pred, average='weighted', zero_division=0)
                rec = recall_score(self.y_test, y_pred, average='weighted', zero_division=0)
                f1 = f1_score(self.y_test, y_pred, average='weighted', zero_division=0)
                result_msg = (
                    f"{model_name} trained (Classification)\n"
                    f"Accuracy: {acc:.4f}\n"
                    f"Precision: {prec:.4f}\n"
                    f"Recall: {rec:.4f}\n"
                    f"F1 Score: {f1:.4f}"
                )
            self.status_bar.showMessage(result_msg)
            QMessageBox.information(self, "Training Results", result_msg)

            self.update_visualization(y_pred)

        except Exception as e:
            self.show_error(f"Error training model: {str(e)}")

    def show_error(self, message):
        """Show error message dialog"""
        QMessageBox.critical(self, "Error", message)
       
    def create_deep_learning_tab(self):
        """Create the deep learning tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        # MLP section
        mlp_group = QGroupBox("Multi-Layer Perceptron")
        mlp_layout = QVBoxLayout()
        
        # Layer configuration
        self.layer_config = []
        layer_btn = QPushButton("Add Layer")
        layer_btn.clicked.connect(self.add_layer_dialog)
        mlp_layout.addWidget(layer_btn)
        
        # Training parameters
        training_params_group = self.create_training_params_group()
        mlp_layout.addWidget(training_params_group)
        
        # Train button
        train_btn = QPushButton("Train Neural Network")
        train_btn.clicked.connect(self.train_neural_network)
        mlp_layout.addWidget(train_btn)
        
        mlp_group.setLayout(mlp_layout)
        layout.addWidget(mlp_group, 0, 0)
        
        # CNN section
        cnn_group = QGroupBox("Convolutional Neural Network")
        cnn_layout = QVBoxLayout()
        
        # CNN architecture controls
        cnn_controls = self.create_cnn_controls()
        cnn_layout.addWidget(cnn_controls)
        
        cnn_group.setLayout(cnn_layout)
        layout.addWidget(cnn_group, 0, 1)
        
        # RNN section
        rnn_group = QGroupBox("Recurrent Neural Network")
        rnn_layout = QVBoxLayout()
        
        # RNN architecture controls
        rnn_controls = self.create_rnn_controls()
        rnn_layout.addWidget(rnn_controls)
        
        rnn_group.setLayout(rnn_layout)
        layout.addWidget(rnn_group, 1, 0)
        
        return widget
    
    def add_layer_dialog(self):
        """Open a dialog to add a neural network layer"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Add Neural Network Layer")
        layout = QVBoxLayout(dialog)
        
        # Layer type selection
        type_layout = QHBoxLayout()
        type_label = QLabel("Layer Type:")
        type_combo = QComboBox()
        type_combo.addItems(["Dense", "Conv2D", "MaxPooling2D", "Flatten", "Dropout"])
        type_layout.addWidget(type_label)
        type_layout.addWidget(type_combo)
        layout.addLayout(type_layout)
        
        # Parameters input
        params_group = QGroupBox("Layer Parameters")
        params_layout = QVBoxLayout()
        
        # Dynamic parameter inputs based on layer type
        self.layer_param_inputs = {}
        
        def update_params():
            # Clear existing parameter inputs
            for widget in list(self.layer_param_inputs.values()):
                params_layout.removeWidget(widget)
                widget.deleteLater()
            self.layer_param_inputs.clear()
            
            layer_type = type_combo.currentText()
            if layer_type == "Dense":
                units_label = QLabel("Units:")
                units_input = QSpinBox()
                units_input.setRange(1, 1000)
                units_input.setValue(32)
                self.layer_param_inputs["units"] = units_input
                
                activation_label = QLabel("Activation:")
                activation_combo = QComboBox()
                activation_combo.addItems(["relu", "sigmoid", "tanh", "softmax"])
                self.layer_param_inputs["activation"] = activation_combo
                
                params_layout.addWidget(units_label)
                params_layout.addWidget(units_input)
                params_layout.addWidget(activation_label)
                params_layout.addWidget(activation_combo)
            
            elif layer_type == "Conv2D":
                filters_label = QLabel("Filters:")
                filters_input = QSpinBox()
                filters_input.setRange(1, 1000)
                filters_input.setValue(32)
                self.layer_param_inputs["filters"] = filters_input
                
                kernel_label = QLabel("Kernel Size:")
                kernel_input = QLineEdit()
                kernel_input.setText("3, 3")
                self.layer_param_inputs["kernel_size"] = kernel_input
                
                params_layout.addWidget(filters_label)
                params_layout.addWidget(filters_input)
                params_layout.addWidget(kernel_label)
                params_layout.addWidget(kernel_input)
            
            elif layer_type == "Dropout":
                rate_label = QLabel("Dropout Rate:")
                rate_input = QDoubleSpinBox()
                rate_input.setRange(0.0, 1.0)
                rate_input.setValue(0.5)
                rate_input.setSingleStep(0.1)
                self.layer_param_inputs["rate"] = rate_input
                
                params_layout.addWidget(rate_label)
                params_layout.addWidget(rate_input)
        
        type_combo.currentIndexChanged.connect(update_params)
        update_params()  # Initial update
        
        params_group.setLayout(params_layout)
        layout.addWidget(params_group)
        
        # Buttons
        btn_layout = QHBoxLayout()
        add_btn = QPushButton("Add Layer")
        cancel_btn = QPushButton("Cancel")
        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)
        
        def add_layer():
            layer_type = type_combo.currentText()
            
            # Collect parameters
            layer_params = {}
            for param_name, widget in self.layer_param_inputs.items():
                if isinstance(widget, QSpinBox):
                    layer_params[param_name] = widget.value()
                elif isinstance(widget, QDoubleSpinBox):
                    layer_params[param_name] = widget.value()
                elif isinstance(widget, QComboBox):
                    layer_params[param_name] = widget.currentText()
                elif isinstance(widget, QLineEdit):
                    # Handle kernel size or other tuple-like inputs
                    if param_name == "kernel_size":
                        layer_params[param_name] = tuple(map(int, widget.text().split(',')))
            
            self.layer_config.append({
                "type": layer_type,
                "params": layer_params
            })
            
            dialog.accept()
        
        add_btn.clicked.connect(add_layer)
        cancel_btn.clicked.connect(dialog.reject)
        
        dialog.exec()
    
    def create_training_params_group(self):
        """Create group for neural network training parameters"""
        group = QGroupBox("Training Parameters")
        layout = QVBoxLayout()
        
        # Batch size
        batch_layout = QHBoxLayout()
        batch_layout.addWidget(QLabel("Batch Size:"))
        self.batch_size_spin = QSpinBox()
        self.batch_size_spin.setRange(1, 1000)
        self.batch_size_spin.setValue(32)
        batch_layout.addWidget(self.batch_size_spin)
        layout.addLayout(batch_layout)
        
        # Epochs
        epochs_layout = QHBoxLayout()
        epochs_layout.addWidget(QLabel("Epochs:"))
        self.epochs_spin = QSpinBox()
        self.epochs_spin.setRange(1, 1000)
        self.epochs_spin.setValue(10)
        epochs_layout.addWidget(self.epochs_spin)
        layout.addLayout(epochs_layout)
        
        # Learning rate
        lr_layout = QHBoxLayout()
        lr_layout.addWidget(QLabel("Learning Rate:"))
        self.lr_spin = QDoubleSpinBox()
        self.lr_spin.setRange(0.0001, 1.0)
        self.lr_spin.setValue(0.001)
        self.lr_spin.setSingleStep(0.001)
        lr_layout.addWidget(self.lr_spin)
        layout.addLayout(lr_layout)
        
        group.setLayout(layout)
        return group
    
    def create_cnn_controls(self):
        """Create controls for Convolutional Neural Network"""
        group = QGroupBox("CNN Architecture")
        layout = QVBoxLayout()
        
        # Placeholder for CNN-specific controls
        label = QLabel("CNN Controls (To be implemented)")
        layout.addWidget(label)
        
        group.setLayout(layout)
        return group
    
    def create_rnn_controls(self):
        """Create controls for Recurrent Neural Network"""
        group = QGroupBox("RNN Architecture")
        layout = QVBoxLayout()
        
        # Placeholder for RNN-specific controls
        label = QLabel("RNN Controls (To be implemented)")
        layout.addWidget(label)
        
        group.setLayout(layout)
        return group
    
    def train_neural_network(self):
        """Train the neural network with current configuration"""
        if not self.layer_config:
            self.show_error("Please add at least one layer to the network")
            return
        
        try:
            # Create and compile model
            model = self.create_neural_network()
            
            # Get training parameters
            batch_size = self.batch_size_spin.value()
            epochs = self.epochs_spin.value()
            learning_rate = self.lr_spin.value()
            
            # Prepare data for neural network
            if len(self.X_train.shape) == 1:
                X_train = self.X_train.reshape(-1, 1)
                X_test = self.X_test.reshape(-1, 1)
            else:
                X_train = self.X_train
                X_test = self.X_test
            
            # One-hot encode target for classification
            y_train = tf.keras.utils.to_categorical(self.y_train)
            y_test = tf.keras.utils.to_categorical(self.y_test)
            
            # Compile model
            optimizer = optimizers.Adam(learning_rate=learning_rate)
            model.compile(optimizer=optimizer,
                          loss='categorical_crossentropy',
                          metrics=['accuracy'])
            
            # Train model
            history = model.fit(X_train, y_train,
                                batch_size=batch_size,
                                epochs=epochs,
                                validation_data=(X_test, y_test),
                                callbacks=[self.create_progress_callback()])
            
            # Update visualization with training history
            self.plot_training_history(history)
            
            self.status_bar.showMessage("Neural Network Training Complete")
            
        except Exception as e:
            self.show_error(f"Error training neural network: {str(e)}")
    
    def create_neural_network(self):
        """Create neural network based on current configuration"""
        model = models.Sequential()
        
        # Add layers based on configuration
        for layer_config in self.layer_config:
            layer_type = layer_config["type"]
            params = layer_config["params"]
            
            if layer_type == "Dense":
                model.add(layers.Dense(**params))
            elif layer_type == "Conv2D":
                # Add input shape for the first layer
                if len(model.layers) == 0:
                    params['input_shape'] = self.X_train.shape[1:]
                model.add(layers.Conv2D(**params))
            elif layer_type == "MaxPooling2D":
                model.add(layers.MaxPooling2D())
            elif layer_type == "Flatten":
                model.add(layers.Flatten())
            elif layer_type == "Dropout":
                model.add(layers.Dropout(**params))
        
        # Add output layer based on number of classes
        num_classes = len(np.unique(self.y_train))
        model.add(layers.Dense(num_classes, activation='softmax'))
                
        return model

   
        
    def train_neural_network(self):
        """Train the neural network"""
        try:
            # Create and compile model
            model = self.create_neural_network()
            
            # Get training parameters
            batch_size = self.batch_size_spin.value()
            epochs = self.epochs_spin.value()
            learning_rate = self.lr_spin.value()
            
            # Compile model
            optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)
            model.compile(optimizer=optimizer,
                        loss='categorical_crossentropy',
                        metrics=['accuracy'])
            
            # Train model
            history = model.fit(self.X_train, self.y_train,
                              batch_size=batch_size,
                              epochs=epochs,
                              validation_data=(self.X_test, self.y_test),
                              callbacks=[self.create_progress_callback()])
            
            # Update visualization with training history
            self.plot_training_history(history)
            
        except Exception as e:
            self.show_error(f"Error training neural network: {str(e)}")
            
    def create_progress_callback(self):
        """Create callback for updating progress bar during training"""
        class ProgressCallback(tf.keras.callbacks.Callback):
            def __init__(self, progress_bar):
                super().__init__()
                self.progress_bar = progress_bar
                
            def on_epoch_end(self, epoch, logs=None):
                progress = int(((epoch + 1) / self.params['epochs']) * 100)
                self.progress_bar.setValue(progress)
                
        return ProgressCallback(self.progress_bar)
        
    def update_visualization(self, y_pred):
        """Update the visualization with current results"""
        self.figure.clear()
        
        # Create appropriate visualization based on data
        if len(np.unique(self.y_test)) > 10:  # Regression
            ax = self.figure.add_subplot(111)
            ax.scatter(self.y_test, y_pred)
            ax.plot([self.y_test.min(), self.y_test.max()],
                   [self.y_test.min(), self.y_test.max()],
                   'r--', lw=2)
            ax.set_xlabel("Actual Values")
            ax.set_ylabel("Predicted Values")
            
        else:  # Classification
            if self.X_train.shape[1] > 2:  # Use PCA for visualization
                pca = PCA(n_components=2)
                X_test_2d = pca.fit_transform(self.X_test)
                
                ax = self.figure.add_subplot(111)
                scatter = ax.scatter(X_test_2d[:, 0], X_test_2d[:, 1],
                                   c=y_pred, cmap='viridis')
                self.figure.colorbar(scatter)
                
            else:  # Direct 2D visualization
                ax = self.figure.add_subplot(111)
                scatter = ax.scatter(self.X_test[:, 0], self.X_test[:, 1],
                                   c=y_pred, cmap='viridis')
                self.figure.colorbar(scatter)
        
        self.canvas.draw()
    def update_visualization(self, y_pred):
        """Update the visualization after training"""
        try:  
            if self.y_test is None or y_pred is None:
                self.show_error("No predictions available to visualize.")
                return
            # Draw the graph with opening new screen
            plt.figure(figsize=(6, 6))
            plt.scatter(self.y_test, y_pred, color='blue', alpha=0.6, label="Predictions")
            plt.plot(self.y_test, self.y_test, color='red', linestyle="dashed", label="y = x (Perfect Fit)")

            plt.xlabel("Actual Values (y_test)")
            plt.ylabel("Predicted Values (y_pred)")
            plt.title("Regression Model Predictions")
            plt.legend()
            plt.grid(True)

            #Show the Graph
            plt.show()

        except Exception as e:
            self.show_error(f"Error is visualization: {str(e)}")

    def update_metrics(self, y_pred):
        """Update metrics display"""
        metrics_text = "Model Performance Metrics:\n\n"
        
        # Calculate appropriate metrics based on problem type
        if len(np.unique(self.y_test)) > 10:  # Regression
            mse = mean_squared_error(self.y_test, y_pred)
            rmse = np.sqrt(mse)
            r2 = self.current_model.score(self.X_test, self.y_test)
            
            metrics_text += f"Mean Squared Error: {mse:.4f}\n"
            metrics_text += f"Root Mean Squared Error: {rmse:.4f}\n"
            metrics_text += f"R² Score: {r2:.4f}"
            
        else:  # Classification
            accuracy = accuracy_score(self.y_test, y_pred)
            conf_matrix = confusion_matrix(self.y_test, y_pred)
            
            metrics_text += f"Accuracy: {accuracy:.4f}\n\n"
            metrics_text += "Confusion Matrix:\n"
            metrics_text += str(conf_matrix)
        
        self.metrics_text.setText(metrics_text)
    def update_model_comparison(self, model_name, y_test, y_pred):
        """Update the model comparison table with evaluation metrics."""
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred, average='weighted', zero_division=1)
        recall = recall_score(y_test, y_pred, average='weighted', zero_division=1)
        f1 = f1_score(y_test, y_pred, average='weighted', zero_division=1)

        row_position = self.comparison_table.rowCount()
        self.comparison_table.insertRow(row_position)

        self.comparison_table.setItem(row_position, 0, QTableWidgetItem(model_name))
        self.comparison_table.setItem(row_position, 1, QTableWidgetItem(f"{accuracy:.4f}"))
        self.comparison_table.setItem(row_position, 2, QTableWidgetItem(f"{precision:.4f}"))
        self.comparison_table.setItem(row_position, 3, QTableWidgetItem(f"{recall:.4f}"))
        self.comparison_table.setItem(row_position, 4, QTableWidgetItem(f"{f1:.4f}"))   
    
    
    def plot_training_history(self, history):
        """Plot neural network training history"""
        self.figure.clear()
        
        # Plot training & validation accuracy
        ax1 = self.figure.add_subplot(211)
        ax1.plot(history.history['accuracy'])
        ax1.plot(history.history['val_accuracy'])
        ax1.set_title('Model Accuracy')
        ax1.set_ylabel('Accuracy')
        ax1.set_xlabel('Epoch')
        ax1.legend(['Train', 'Test'])
        
        # Plot training & validation loss
        ax2 = self.figure.add_subplot(212)
        ax2.plot(history.history['loss'])
        ax2.plot(history.history['val_loss'])
        ax2.set_title('Model Loss')
        ax2.set_ylabel('Loss')
        ax2.set_xlabel('Epoch')
        ax2.legend(['Train', 'Test'])
        
        self.figure.tight_layout()
        self.canvas.draw()
    def plot_confusion_matrix(self, y_test, y_pred, class_names):
        """Plot Confusion Matrix for classification models"""
        try:
            cm = confusion_matrix(y_test, y_pred)
            disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=class_names)

            plt.figure(figsize=(6, 6))
            disp.plot(cmap="Blues", values_format="d")
            plt.title("Confusion Matrix")
            plt.show()

        except Exception as e:
            self.show_error(f"Error in Confusion Matrix: {str(e)}")
    
    
    def plot_roc_auc(self, y_test, y_pred_proba):
        """Plot ROC-AUC Curve for classification models"""
        try:
            fpr, tpr, _ = roc_curve(y_test, y_pred_proba)
            roc_auc = auc(fpr, tpr)

            plt.figure(figsize=(6, 6))
            plt.plot(fpr, tpr, color='blue', lw=2, label=f'ROC curve (AUC = {roc_auc:.2f})')
            plt.plot([0, 1], [0, 1], color='gray', linestyle='--')  # Rastgele model
            plt.xlabel("False Positive Rate")
            plt.ylabel("True Positive Rate")
            plt.title("ROC-AUC Curve")
            plt.legend(loc="lower right")
            plt.show()

        except Exception as e:
            self.show_error(f"Error in ROC-AUC Curve: {str(e)}")
    
    
    def show_error(self, message):
        """Show error message dialog"""
        QMessageBox.critical(self, "Error", message)

def main():
    """Main function to start the application"""
    app = QApplication(sys.argv)
    window = MLCourseGUI()
    window.show()
    sys.exit(app.exec())

if __name__ == '__main__':
    main()

