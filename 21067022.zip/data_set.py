from sklearn.datasets import load_boston
import numpy as np
import pandas as pd

# Veri setini yükle
boston = load_boston()

# DataFrame oluştur
df = pd.DataFrame(boston.data, columns=boston.feature_names)
df['MEDV'] = boston.target  # Hedef değişken (Median House Value)

# CSV olarak kaydet
df.to_csv("boston_housing.csv", index=False)
print("Dataset indirildi: boston_housing.csv")